
public interface RoomDiscoveryListener {
    void onRoomDiscovered(RoomInfo room);
}
